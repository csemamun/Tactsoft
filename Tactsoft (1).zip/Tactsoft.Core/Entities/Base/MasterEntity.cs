﻿using Microsoft.EntityFrameworkCore;

namespace Tactsoft.Core.Entities.Base
{
    public class MasterEntity
    {
        public long Id { get; set; }
    }
}