﻿namespace Tactsoft.Core
{
    public class CommonVariables
    {
        public const int pageIndex = 0;
        public const int pageSize = 10;
        public const int DropdownSize = 15;
        public const string AvatarLocation = "images/profiles";
    }
}
